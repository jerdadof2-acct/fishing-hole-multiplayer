Kitty Creek Asset Bundle
Generated: 2025-11-01 13:05:58

Place the entire `assets` folder at your web root so these paths resolve:
  /assets/textures/waterNormals1.jpg
  /assets/textures/waterNormals2.jpg
  /assets/textures/caustics_loop.jpg
  /assets/textures/particle.png
  /assets/audio/splash.wav
  /assets/audio/reel_clicks.wav
  /assets/audio/tug.wav

These are placeholder textures/sounds made to avoid 404s and give you a decent baseline:
- waterNormals*.jpg: Procedural normal maps (512x512), tile-friendly.
- caustics_loop.jpg: Single-frame interference caustics; scroll offsets in code for motion.
- particle.png: Soft round sprite with alpha for water micro-particles.
- splash.wav: Short noise burst with low thump.
- reel_clicks.wav: Click train with light tone for a mechanical reel feel.
- tug.wav: Short low pitch slide for line tugs.

You can replace any file with your preferred asset later, keeping the same filenames.
